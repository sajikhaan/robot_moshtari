
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
import pickle
import time
from make_pdf import generate_pdf

def start_scraping(message):
    user_id = message.from_user.id
    province = message.text.strip()

    chrome_options = Options()
    chrome_options.add_argument('--headless')
    chrome_options.add_argument('--no-sandbox')
    chrome_options.add_argument('--disable-dev-shm-usage')
    driver = webdriver.Chrome(options=chrome_options)

    try:
        with open(f"sessions/{user_id}_cookies.pkl", "rb") as f:
            cookies = pickle.load(f)

        driver.get("https://divar.ir")
        for cookie in cookies:
            driver.add_cookie(cookie)
        driver.get(f"https://divar.ir/s/{province}")

        time.sleep(2)
        links = driver.find_elements(By.CSS_SELECTOR, 'a.kt-post-card__title')
        urls = [link.get_attribute("href") for link in links[:10]]

        numbers = []
        for url in urls:
            driver.get(url)
            time.sleep(2)
            try:
                number = driver.find_element(By.CSS_SELECTOR, '.kt-unexpandable-row__action').text
                numbers.append(number)
            except:
                continue

        pdf_path = generate_pdf(user_id, numbers)
        message.bot.send_document(user_id, open(pdf_path, "rb"))

    except Exception as e:
        message.bot.send_message(user_id, f"خطا در جست‌وجو: {e}")
    finally:
        driver.quit()
