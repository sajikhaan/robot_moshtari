
import time
import os
import pickle
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

def start_login_flow(user_id, phone, bot):
    chrome_options = Options()
    chrome_options.add_argument('--headless')
    chrome_options.add_argument('--no-sandbox')
    chrome_options.add_argument('--disable-dev-shm-usage')
    driver = webdriver.Chrome(options=chrome_options)

    try:
        wait = WebDriverWait(driver, 15)
        driver.get("https://divar.ir/s/tehran")

        # کلیک روی "ثبت آگهی"
        submit_ad_btn = wait.until(EC.element_to_be_clickable((By.XPATH, '//span[contains(text(),"ثبت آگهی")]')))
        driver.execute_script("arguments[0].click();", submit_ad_btn)  # کلیک با جاوااسکریپت

        # صبر برای نمایش input شماره
        phone_input = wait.until(EC.presence_of_element_located((By.NAME, "mobile")))
        phone_input.send_keys(phone)
        phone_input.submit()

        bot.send_message(user_id, "کدی که از دیوار دریافت کردی رو وارد کن:")
        code = wait_for_code(bot, user_id)

        code_input = wait.until(EC.presence_of_element_located((By.NAME, "code")))
        code_input.send_keys(code)
        code_input.submit()

        time.sleep(2)
        os.makedirs("sessions", exist_ok=True)
        with open(f"sessions/{user_id}_cookies.pkl", "wb") as f:
            pickle.dump(driver.get_cookies(), f)

        bot.send_message(user_id, "✅ حساب با موفقیت فعال شد.")
        return True

    except Exception as e:
        print("Login error:", e)
        bot.send_message(user_id, f"❌ خطا در ورود: {e}")
        return False

    finally:
        driver.quit()

def wait_for_code(bot, user_id):
    code_holder = {"code": None}

    @bot.message_handler(func=lambda msg: msg.from_user.id == user_id and msg.text.isdigit())
    def get_code(message):
        code_holder["code"] = message.text

    while not code_holder["code"]:
        time.sleep(1)
    return code_holder["code"]
