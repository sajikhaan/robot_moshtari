import telebot
import socks
import telebot.apihelper

# telebot.apihelper.proxy = {
#     'https': 'socks5h://127.0.0.1:5442'
# }
# import telebot
from diwar_login import start_login_flow
from search_ads import start_scraping
from make_pdf import generate_pdf

BOT_TOKEN = '7399766887:AAH1CoLOBPNyWVLEJNSOZJzauRhIJoR14QE'
bot = telebot.TeleBot(BOT_TOKEN)

user_sessions = {}

@bot.message_handler(commands=['start'])
def start(message):
    user_id = message.from_user.id
    markup = telebot.types.ReplyKeyboardMarkup(resize_keyboard=True)
    markup.row("فعال‌سازی حساب", "سرچ")
    bot.send_message(user_id, "سلام! یکی از گزینه‌ها رو انتخاب کن:", reply_markup=markup)

@bot.message_handler(func=lambda msg: msg.text == "فعال‌سازی حساب")
def activate_account(message):
    user_id = message.from_user.id
    bot.send_message(user_id, "شماره تلفنتو بفرست (مثلاً 09xxxxxxxxx):")
    bot.register_next_step_handler(message, get_phone)

def get_phone(message):
    user_id = message.from_user.id
    phone = message.text.strip()
    bot.send_message(user_id, "در حال ارسال شماره به دیوار...")
    status = start_login_flow(user_id, phone, bot)
    if not status:
        bot.send_message(user_id, "خطا در ارسال شماره. لطفاً دوباره تلاش کن.")

@bot.message_handler(func=lambda msg: msg.text == "سرچ")
def search(message):
    user_id = message.from_user.id
    provinces = ["تهران", "اصفهان", "مشهد", "شیراز", "تبریز"]
    markup = telebot.types.ReplyKeyboardMarkup(resize_keyboard=True)
    for p in provinces:
        markup.row(p)
    bot.send_message(user_id, "یک استان رو انتخاب کن:", reply_markup=markup)
    bot.register_next_step_handler(message, start_scraping)

print("Bot is running...")
bot.polling(timeout=60, long_polling_timeout=45)

