
from fpdf import FPDF
import os

def generate_pdf(user_id, numbers):
    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("Arial", size=12)
    for num in numbers:
        pdf.cell(200, 10, txt=num, ln=True)
    os.makedirs("output", exist_ok=True)
    path = f"output/{user_id}_numbers.pdf"
    pdf.output(path)
    return path
